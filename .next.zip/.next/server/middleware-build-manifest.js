globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/73cedf37cb68c1ed.js",
      "static/chunks/turbopack-683f146bbc63c232.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/73cedf37cb68c1ed.js",
      "static/chunks/turbopack-ad6df04d1338fe2d.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/c85a7d07e7b82c9a.js",
    "static/chunks/c20516c263ef3a09.js",
    "static/chunks/9fc092503280ba10.js",
    "static/chunks/69eb54e945a27e22.js",
    "static/chunks/turbopack-c611c2ef7b97cc8f.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];