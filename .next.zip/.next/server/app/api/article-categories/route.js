var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/article-categories/route.js")
R.c("server/chunks/[root-of-the-server]__50db66f0._.js")
R.c("server/chunks/_955a2098._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__36952e5e._.js")
R.m(31044)
R.m(3168)
module.exports=R.m(3168).exports
