var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/uploads/route.js")
R.c("server/chunks/[root-of-the-server]__eba704cd._.js")
R.c("server/chunks/_955a2098._.js")
R.c("server/chunks/[root-of-the-server]__1fb69317._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__36952e5e._.js")
R.m(54862)
R.m(35868)
module.exports=R.m(35868).exports
