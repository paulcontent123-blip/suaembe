var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/orders/[id]/mock-pay/route.js")
R.c("server/chunks/[root-of-the-server]__5b2d23a2._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__36952e5e._.js")
R.m(9264)
R.m(39999)
module.exports=R.m(39999).exports
