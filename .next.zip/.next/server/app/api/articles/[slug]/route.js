var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/articles/[slug]/route.js")
R.c("server/chunks/[root-of-the-server]__de5bfb1e._.js")
R.c("server/chunks/_955a2098._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__36952e5e._.js")
R.m(12389)
R.m(64394)
module.exports=R.m(64394).exports
