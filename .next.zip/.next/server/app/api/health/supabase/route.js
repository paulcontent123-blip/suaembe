var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/health/supabase/route.js")
R.c("server/chunks/[root-of-the-server]__8fce816a._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__36952e5e._.js")
R.m(31983)
R.m(26608)
module.exports=R.m(26608).exports
