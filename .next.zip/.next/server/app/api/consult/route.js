var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/consult/route.js")
R.c("server/chunks/[root-of-the-server]__3888cc9c._.js")
R.c("server/chunks/_955a2098._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__36952e5e._.js")
R.m(5771)
R.m(73346)
module.exports=R.m(73346).exports
