var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/development-milestones/route.js")
R.c("server/chunks/[root-of-the-server]__5d9db226._.js")
R.c("server/chunks/_955a2098._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__36952e5e._.js")
R.m(41897)
R.m(93072)
module.exports=R.m(93072).exports
