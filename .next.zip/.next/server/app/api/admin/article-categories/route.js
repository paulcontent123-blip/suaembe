var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/article-categories/route.js")
R.c("server/chunks/[root-of-the-server]__3e3d093f._.js")
R.c("server/chunks/_955a2098._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__36952e5e._.js")
R.m(8674)
R.m(8423)
module.exports=R.m(8423).exports
