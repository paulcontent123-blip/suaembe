var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/partners/[id]/services/route.js")
R.c("server/chunks/[root-of-the-server]__b17743f7._.js")
R.c("server/chunks/_955a2098._.js")
R.c("server/chunks/[root-of-the-server]__36952e5e._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.m(16242)
R.m(2275)
module.exports=R.m(2275).exports
