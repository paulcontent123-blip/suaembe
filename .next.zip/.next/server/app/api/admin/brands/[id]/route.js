var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/brands/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__f8e3a705._.js")
R.c("server/chunks/_955a2098._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__36952e5e._.js")
R.m(14754)
R.m(80605)
module.exports=R.m(80605).exports
