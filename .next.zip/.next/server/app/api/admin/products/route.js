var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/products/route.js")
R.c("server/chunks/[root-of-the-server]__004eb77c._.js")
R.c("server/chunks/_955a2098._.js")
R.c("server/chunks/[root-of-the-server]__36952e5e._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.m(50429)
R.m(3976)
module.exports=R.m(3976).exports
