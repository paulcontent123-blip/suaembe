var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/users/route.js")
R.c("server/chunks/[root-of-the-server]__f93526b4._.js")
R.c("server/chunks/_955a2098._.js")
R.c("server/chunks/[root-of-the-server]__36952e5e._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.m(38653)
R.m(66129)
module.exports=R.m(66129).exports
