var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/consults/route.js")
R.c("server/chunks/[root-of-the-server]__f0a8584e._.js")
R.c("server/chunks/_955a2098._.js")
R.c("server/chunks/[root-of-the-server]__36952e5e._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.m(21745)
R.m(27451)
module.exports=R.m(27451).exports
