var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/listings/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__db90f3b2._.js")
R.c("server/chunks/_955a2098._.js")
R.c("server/chunks/[root-of-the-server]__1fb69317._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__36952e5e._.js")
R.m(37560)
R.m(5672)
module.exports=R.m(5672).exports
