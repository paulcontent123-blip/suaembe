var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/listings/route.js")
R.c("server/chunks/[root-of-the-server]__c5ad0fb8._.js")
R.c("server/chunks/_955a2098._.js")
R.c("server/chunks/[root-of-the-server]__36952e5e._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.m(47039)
R.m(56093)
module.exports=R.m(56093).exports
