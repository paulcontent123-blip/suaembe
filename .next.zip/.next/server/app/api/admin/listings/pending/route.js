var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/listings/pending/route.js")
R.c("server/chunks/[root-of-the-server]__d4119ff5._.js")
R.c("server/chunks/_955a2098._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__36952e5e._.js")
R.m(86851)
R.m(68822)
module.exports=R.m(68822).exports
