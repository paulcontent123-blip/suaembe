var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cron/dispatch-notifications/route.js")
R.c("server/chunks/[root-of-the-server]__a692ef1b._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__36952e5e._.js")
R.m(72291)
R.m(94853)
module.exports=R.m(94853).exports
