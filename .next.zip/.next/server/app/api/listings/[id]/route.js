var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/listings/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__91b34fe2._.js")
R.c("server/chunks/_955a2098._.js")
R.c("server/chunks/[root-of-the-server]__1fb69317._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__36952e5e._.js")
R.m(9475)
R.m(63877)
module.exports=R.m(63877).exports
