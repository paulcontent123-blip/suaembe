var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/brands/route.js")
R.c("server/chunks/[root-of-the-server]__a03ed029._.js")
R.c("server/chunks/_955a2098._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__36952e5e._.js")
R.m(658)
R.m(39484)
module.exports=R.m(39484).exports
