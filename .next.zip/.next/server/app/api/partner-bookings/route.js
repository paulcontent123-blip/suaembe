var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/partner-bookings/route.js")
R.c("server/chunks/[root-of-the-server]__73212a4c._.js")
R.c("server/chunks/_955a2098._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__36952e5e._.js")
R.m(27945)
R.m(25525)
module.exports=R.m(25525).exports
