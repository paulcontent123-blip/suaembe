var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/partners/route.js")
R.c("server/chunks/[root-of-the-server]__8fd89147._.js")
R.c("server/chunks/_955a2098._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__36952e5e._.js")
R.m(63568)
R.m(81871)
module.exports=R.m(81871).exports
