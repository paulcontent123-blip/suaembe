var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/babies/[id]/feeding-schedule/route.js")
R.c("server/chunks/[root-of-the-server]__3bfd3ddf._.js")
R.c("server/chunks/_955a2098._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__36952e5e._.js")
R.m(55733)
R.m(53121)
module.exports=R.m(53121).exports
