var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__9fcd478b._.js")
R.c("server/chunks/[root-of-the-server]__36952e5e._.js")
R.m(38285)
R.m(77067)
module.exports=R.m(77067).exports
