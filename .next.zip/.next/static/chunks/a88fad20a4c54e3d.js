__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/73cedf37cb68c1ed.js",
  "static/chunks/turbopack-ad6df04d1338fe2d.js"
])
