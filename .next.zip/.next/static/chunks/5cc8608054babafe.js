__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/73cedf37cb68c1ed.js",
  "static/chunks/turbopack-683f146bbc63c232.js"
])
